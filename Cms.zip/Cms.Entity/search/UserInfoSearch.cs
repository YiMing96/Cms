﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cms.Entity.Search
{
    public class UserInfoSearch : BaseSeach
    {
        public string? UserName { get; set; }
        public string? UserEmail { get; set; }



    }
}
