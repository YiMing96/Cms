﻿namespace Cms.Attributes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class NoCheckAttribute:Attribute
    {
    }
}
